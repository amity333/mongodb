package com.cg.ctrl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;


@RestController
@RequestMapping("/proddemo")
public class ProductController 
{
	@Autowired
	ProductDao proDao;
	@PostMapping(path="/create/",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String createprod(@RequestBody Product prod)
	{
		proDao.save(prod);
		return ("data Inserted in MongoDB");		
	}
	
	@GetMapping(value="/fetchAllProd",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Product> fetchAllProd()
	{
		return proDao.findAll();
	}
	
	@DeleteMapping(value="/deleteProduct/{pid}",produces=MediaType.APPLICATION_JSON_VALUE)
	public Product deleteProductById(@PathVariable("pid") String prodId)
	{
		Product prod1  = proDao.findById(prodId).get();
		proDao.deleteById(prodId); 
		return prod1;
	}
	
	@PutMapping(path="/update/{pid}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateprod(@RequestBody Product prod,@PathVariable("pid")String prodId)
	{
		
		//prod.setId(prodId);
		proDao.save(prod);
		return ("data updated in MongoDB");		
	}

}
